import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;

public class Menu{
	public Boolean main=true;
	public Boolean newGame = false;
	public Boolean saveGame = false;
	public Boolean loadGame = false;
	public Boolean options = false;
	public Boolean enter = false;
	public int menuItems = 0;
	
	
	public void drawMenu(GameContainer gc, Graphics g, float x, float y,int item) {
		if(main){
			menuItems=4;
			g.drawString("Menu", x, y);
			g.drawString("New Game", x, y+50);
			g.drawString("Load Game", x, y+100);
			g.drawString("Options", x, y+150);
			g.drawString("EXIT", x, y+200);
			g.drawString("-->", x-50, y+item*50);
			if(enter && item*50==50){
				main=false;
				newGame=true;
			}
			else if(enter && item*50==100){
				main=false;
				loadGame=true;
			}
			else if(enter && item*50==150){
				main=false;
				options=true;
			}
			else if(enter && item*50==200){
				gc.exit();
				
			}
		}
		else if(newGame){
			newGame=true;
		}
		else if(loadGame){
			menuItems=4;
			g.drawString("Saved Games :", x, y);
			g.drawString("1.", x, y+50);
			g.drawString("2", x, y+100);
			g.drawString("3", x, y+150);
			g.drawString("BACK", x, y+200);
			g.drawString("-->", x-50, y+item*50);
			if(enter && item*50==50){
				
			}
			else if(enter && item*50==100){
				
			}
			else if(enter && item*50==150){
			
			}
			else if(enter && item*50==200){
				loadGame=false;
				main=true;
				
			}
		}
		else if(options){
			menuItems=4;
			g.drawString("Options", x, y);
			g.drawString("Option 1 ", x, y+50);
			g.drawString("Option 2 ", x, y+100);
			g.drawString("Option 3 ", x, y+150);
			g.drawString("BACK ", x, y+200);
			g.drawString("-->", x-50, y+item*50);
			if(enter && item*50==50){
				
			}
			else if(enter && item*50==100){
				
			}
			else if(enter && item*50==150){
				
			}
			else if(enter && item*50==200){
				options=false;
				main=true;
			}
		}
	}
	public void drawPause(GameContainer gc, Graphics g, float x, float y,int item){
		if(main){
			menuItems=3;
			g.drawString("Pause", x, y);
			g.drawString("Save Game", x, y+50);
			g.drawString("Load Game", x, y+100);
			g.drawString("EXIT", x, y+150);
			g.drawString("-->", x-50, y+item*50);
			if(enter && item*50==50){
				main=false;
				saveGame=true;
			}
			else if(enter && item*50==100){
				main=false;
				loadGame=true;
			}
			else if(enter && item*50==150){
				gc.exit();;
				
			}
			
		}
		else if(saveGame){
			menuItems=4;
			g.drawString("Save Menu", x, y);
			g.drawString("Slot1", x, y+50);
			g.drawString("Slot2", x, y+100);
			g.drawString("Slot3", x, y+150);
			g.drawString("BACK", x, y+200);
			g.drawString("-->", x-50, y+item*50);
			if(enter && item*50==50){
				
			}
			else if(enter && item*50==100){
				
			}
			else if(enter && item*50==150){
			
			}
			else if(enter && item*50==200){
				saveGame=false;
				main=true;
				
			}
		}
		else if(loadGame){
			menuItems=4;
			g.drawString("Load Menu", x, y);
			g.drawString("Slot1", x, y+50);
			g.drawString("Slot2", x, y+100);
			g.drawString("Slot3", x, y+150);
			g.drawString("Slot3", x, y+200);
			g.drawString("-->", x-50, y+item*50);
			if(enter && item*50==50){
				
			}
			else if(enter && item*50==100){
				
			}
			else if(enter && item*50==150){
			
			}
			else if(enter && item*50==200){
				loadGame=false;
				main=true;
				
			}
		}
		
		
		}
	
	
	
}