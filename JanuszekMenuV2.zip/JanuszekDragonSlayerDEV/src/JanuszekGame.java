import java.util.logging.Level;
import java.util.logging.Logger;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.ControlledInputReciever;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class JanuszekGame extends BasicGame {
	public int x=200;
	public int y=200;
	public static Boolean keyUp = false;
	public static Boolean keyDown = false;
	public static Boolean keyLeft = false;
	public static Boolean keyRight = false;
	public static Boolean keyESC = false;
	public static Boolean keyENTER = false;
	public static Boolean menuShown=true;
	public static Boolean pause=false;
	public int arrow;
	Menu menu= new Menu();
	public JanuszekGame(String Januszek){
		super(Januszek);
		
	}


	public void init(GameContainer gc) throws SlickException {
		
	}

	public void update(GameContainer gc, int i) throws SlickException {
		if(menuShown){
			if(keyUp) arrow--;
			if(keyDown) arrow++;
			if(keyENTER) {
				menu.enter=true;
				gc.sleep(100);
			}
			if(!keyENTER) menu.enter=false;
			if(menu.newGame){
				menuShown=false;
			}
			gc.sleep(50);
		}
		if(pause){
			if(keyUp) arrow--;
			if(keyDown) arrow++;
			if(keyENTER) {
				menu.enter=true;
				gc.sleep(100);
			}
			if(!keyENTER) menu.enter=false;
			gc.sleep(50);
			
		}
		if(keyESC && !menuShown) {
			pause=true;
			menu.main=true;
		}
	}
	public interface KeyListener extends ControlledInputReciever {}
	public void keyPressed(int key,char c){
		if(key == Input.KEY_UP) keyUp=true;
		if(key == Input.KEY_DOWN) keyDown=true;
		if(key == Input.KEY_LEFT) keyLeft=true;
		if(key == Input.KEY_RIGHT) keyRight=true;
		if(key == Input.KEY_ESCAPE) keyESC=true;
		if(key == Input.KEY_ENTER) keyENTER=true;
	}
	public void keyReleased(int key,char c){
		if(key == Input.KEY_UP) keyUp=false;
		if(key == Input.KEY_DOWN) keyDown=false;
		if(key == Input.KEY_LEFT) keyLeft=false;
		if(key == Input.KEY_RIGHT) keyRight=false;
		if(key == Input.KEY_ESCAPE) keyESC=false;
		if(key == Input.KEY_ENTER) keyENTER=false;
	}
	
	
	public void render(GameContainer gc, Graphics g) throws SlickException{
		if(arrow>menu.menuItems) arrow--;
		if(arrow<1) arrow++;
		if (menuShown){
			menu.drawMenu(gc,g,(gc.getWidth() / 5), (gc.getHeight() / 5),arrow);
		}
		if(pause){
			menu.drawPause(gc,g,(gc.getWidth() / 5), (gc.getHeight() / 5),arrow);
		}
		if(!menuShown){
			g.drawString("Game HERE", 500, 500);
		}
	}
	
	public static void main(String[] args){
		try{
			AppGameContainer appgc;
			appgc = new AppGameContainer(new JanuszekGame("Januszek"));
			appgc.setDisplayMode(appgc.getScreenWidth(), appgc.getScreenHeight(), true);
			appgc.setTargetFrameRate(120);
			appgc.start();
		}
		catch (SlickException ex)
		{
			Logger.getLogger(JanuszekGame.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}
