import org.newdawn.slick.ControlledInputReciever;
import org.newdawn.slick.Input;

public class KeyInput {

	public KeyInput(){
		
	}
	public static Boolean keyUp = true;
	public static Boolean keyDown = false;
	public static Boolean keyLeft = false;
	public static Boolean keyRight = false;
	public static Boolean keyESC = false;
	public static Boolean keyENTER = false;
	public interface KeyListener extends ControlledInputReciever {}
	public void keyPressed(int key,char c){
		
		if(key == Input.KEY_UP) keyUp=true;
		if(key == Input.KEY_DOWN) keyDown=true;
		if(key == Input.KEY_LEFT) keyLeft=true;
		if(key == Input.KEY_RIGHT) keyRight=true;
		if(key == Input.KEY_ESCAPE) keyESC=true;
		if(key == Input.KEY_ENTER) keyENTER=true;
	}
	public void keyReleased(int key,char c){
		if(key == Input.KEY_UP) keyUp=false;
		if(key == Input.KEY_DOWN) keyDown=false;
		if(key == Input.KEY_LEFT) keyLeft=false;
		if(key == Input.KEY_RIGHT) keyRight=false;
		if(key == Input.KEY_ESCAPE) keyESC=false;
		if(key == Input.KEY_ENTER) keyENTER=false;
	}
	
}
