import java.util.logging.Level;
import java.util.logging.Logger;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;

public class JanuszekGame extends BasicGame {
	public int x=200;
	public int y=200;
	KeyInput input = new KeyInput();
	public JanuszekGame(String Januszek){
		super(Januszek);
		
	}


	public void init(GameContainer gc) throws SlickException {
		
	}

	public void update(GameContainer gc, int i) throws SlickException {
		
		
	}
	public void render(GameContainer gc, Graphics g) throws SlickException{
		g.drawRect(x, y, 64, 64);
		
	}
	
	public static void main(String[] args){
		try{
			AppGameContainer appgc;
			appgc = new AppGameContainer(new JanuszekGame("Januszek"));
			appgc.setDisplayMode(appgc.getScreenWidth(), appgc.getScreenHeight(), true);
			appgc.setTargetFrameRate(120);
			appgc.start();
		}
		catch (SlickException ex)
		{
			Logger.getLogger(JanuszekGame.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}
