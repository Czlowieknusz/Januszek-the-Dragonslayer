import org.newdawn.slick.GameContainer;

public class Menu{
	public static void Logic(GameContainer gc){
		
	}
}