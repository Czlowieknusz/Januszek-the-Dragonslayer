package JanuszekDragonSlayer.Dialogs;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class TXTReader {

	public static ArrayList<String> savingDialogsInArray(String fileName) throws IOException {
		ArrayList<String> arrList = new ArrayList<String>();
		try (Scanner scanner = new Scanner(new File(newPath(fileName)))) {

			while (scanner.hasNext()) {
				arrList.add(scanner.nextLine());
			}
			scanner.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return arrList;
	}

	public static String newPath(String fileName) {
		return "Dialogs\\" + fileName;
	}
}
