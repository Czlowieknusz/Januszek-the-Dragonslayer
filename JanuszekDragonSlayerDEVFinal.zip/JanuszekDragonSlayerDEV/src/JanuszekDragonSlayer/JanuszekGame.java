package JanuszekDragonSlayer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.newdawn.slick.Animation;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.geom.Rectangle;

import JanuszekDragonSlayer.Creatures.Creature;
import JanuszekDragonSlayer.Creatures.ID;
import JanuszekDragonSlayer.Dialogs.TXTReader;
import JanuszekDragonSlayer.Interactions.fightImages;
import JanuszekDragonSlayer.Interactions.fightWindow;

public class JanuszekGame extends BasicGame {
	private static int WIDTH = 639, HEIGHT = 784;
	public int actualAnswersSize = 0;
	public int dialogIteration = 0;
	public int fontHeight = 20;
	public int answerIteration = 0;
	public int x = 350;
	public int y = 300;
	public int velX = 0;
	public int velY = 0;
	public int level = 0;
	public static Boolean areActualAnswers = false;
	public static Boolean keyUp = false;
	public static Boolean keyDown = false;
	public static Boolean keyLeft = false;
	public static Boolean keyRight = false;
	public static Boolean keyESC = false;
	public static Boolean keyENTER = false;
	public static Boolean keySPACE = false;
	public static Boolean menuShown = true;
	public static Boolean pause = false;
	public static Boolean dialogableEntity = false;
	public static Boolean fightableEntity = false;

	public static int arrow;
	CollisionDet detection = new CollisionDet();
	Menu menu = new Menu();
	fightWindow fW;
	fightImages fI;
	public Rectangle character;
	public static Map<Rectangle, Creature> enemiesLvl0 = new HashMap<Rectangle, Creature>();
	Map<Rectangle, ID> dialogCharsLvl1 = new HashMap<Rectangle, ID>();

	private ArrayList<String> pietruszkoSentence1;
	private ArrayList<String> pietruszkoAnswers1;
	private ArrayList<String> listOfSentences;
	private ArrayList<String> listOfAnswers;
	private ArrayList<String> actualAnswers;

	static public Creature player;
	static public Creature ratata;
	static public Creature enemy;

	public Rectangle rect123;
	Animation heroWalksNorth;
	Animation heroWalksSouth;
	Animation heroWalksEast;
	Animation heroWalksWest;
	Image tlo;
	Image pietruszko;
	Image pietruszkoBig;
	Image tloDoorOpen;
	Image inn;
	Image fightBg;

	ID id;

	public JanuszekGame(String Januszek) {
		super(Januszek);
	}

	public void init(GameContainer gc) throws SlickException {
		heroWalksNorth = new Animation(new SpriteSheet(new Image("spriteMoveNorth.png"), 16, 19), 80);
		heroWalksSouth = new Animation(new SpriteSheet(new Image("spriteMoveSouth.png"), 16, 19), 80);
		heroWalksEast = new Animation(new SpriteSheet(new Image("spriteMoveEast.png"), 16, 19), 80);
		heroWalksWest = new Animation(new SpriteSheet(new Image("spriteMoveWest.png"), 16, 19), 80);
		tlo = new Image("background1_doorclosed.png");
		tloDoorOpen = new Image("background1_bigHouseOpen.png");
		pietruszko = new Image("pietruszkoSmall.png");
		pietruszkoBig = new Image("pietruszko.png");
		inn = new Image("inn.png");
		try {
			pietruszkoSentence1 = TXTReader.savingDialogsInArray("TofikConversation1.txt");
			pietruszkoAnswers1 = TXTReader.savingDialogsInArray("TofikConersationAnswers1.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		player = new Creature(40, 3, 7, 2, ID.PLAYER, 0, 0);
		fI = new fightImages();
		enemiesLvl0.put(detection.RectEnemies[0], new Creature(20, 2, 5, 0, ID.RATATA, 300, 300));
		enemiesLvl0.put(detection.RectEnemies[1], new Creature(20, 2, 5, 0, ID.RATATA, 350, 200));
		dialogCharsLvl1.put(detection.RectDialogable[0], ID.PIETRUSZKO);
	}

	public void keyPressed(int key, char c) {
		if (fightableEntity == false) {
			if (key == Input.KEY_UP)
				keyUp = true;
			if (key == Input.KEY_DOWN)
				keyDown = true;
			if (key == Input.KEY_LEFT)
				keyLeft = true;
			if (key == Input.KEY_RIGHT)
				keyRight = true;
			if (key == Input.KEY_ESCAPE)
				keyESC = true;
			if (key == Input.KEY_ENTER)
				keyENTER = true;
		} else {
			if (key == Input.KEY_UP && fightWindow.chosenOption > 0) {
				fightWindow.chosenOption--;
			} else if (key == Input.KEY_DOWN && fightWindow.chosenOption < 3)
				fightWindow.chosenOption++;
			else if (key == Input.KEY_ENTER) {
				fightableEntity = fightWindow.choosingOption();
			}
			if (listOfSentences == null) {
			}
		}
		if (key == Input.KEY_SPACE) {
			dialogableEntity = nearDialogable(dialogCharsLvl1);
			if (fightableEntity = nearEnemy(enemiesLvl0)) {
				fW = new fightWindow(player, enemy);
			}
		}
		if (listOfSentences != null) {
			if (key == Input.KEY_W && answerIteration > 0)
				answerIteration--;
			else if (key == Input.KEY_S && answerIteration < actualAnswersSize - 1)
				answerIteration++;
			else if (key == Input.KEY_ENTER) {
				if (keySPACE) {
					dialogLogic();
				}
			}
		}
	}

	public void keyReleased(int key, char c) {
		if (key == Input.KEY_UP)
			keyUp = false;
		if (key == Input.KEY_DOWN)
			keyDown = false;
		if (key == Input.KEY_LEFT)
			keyLeft = false;
		if (key == Input.KEY_RIGHT)
			keyRight = false;
		if (key == Input.KEY_ESCAPE)
			keyESC = false;
		if (key == Input.KEY_ENTER)
			keyENTER = false;
	}

	public boolean nearDialogable(Map<Rectangle, ID> map) {
		for (Entry<Rectangle, ID> entry : map.entrySet()) {
			if (character.intersects(entry.getKey())) {
				keySPACE = true;
				if (entry.getValue() == ID.PIETRUSZKO) {
					listOfSentences = pietruszkoSentence1;
					listOfAnswers = pietruszkoAnswers1;
				}
				return true;
			}
		}
		return false;
	}

	public boolean nearEnemy(Map<Rectangle, Creature> map) {
		for (Entry<Rectangle, Creature> entry : map.entrySet()) {
			if (character.intersects(entry.getKey())) {
				keySPACE = true;
				enemy = entry.getValue();
				return true;
			}
		}
		return false;
	}

	private void dialogLogic() {
		if (dialogableEntity) {
			if (isWordInListArray("[ok]"))
				dialogIteration = 0;
			else if (isWordInListArray("[Koniec]")) {
				keySPACE = false;
				dialogIteration = 0;
			} else if (answerIteration == 0)
				dialogIteration += 9;
			else if (answerIteration == 1)
				dialogIteration += 10;
			else if (answerIteration == 2)
				dialogIteration += 11;
			answerIteration = 0;
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			actualAnswers = null;
		}
	}

	private boolean isWordInListArray(String word) {
		String[] answer = actualAnswers.get(answerIteration).split(" ");
		for (String str : answer) {
			if (str.trim().contains(word))
				return true;
		}
		return false;
	}

	public void displayingDialogWindow(GameContainer gc, Graphics g) {
		if (keySPACE) {
			g.setColor(Color.gray);
			if (actualAnswers == null) {
				actualAnswers = new ArrayList<String>();
				areActualAnswers = false;
				actualAnswersSize = 0;
			}
			g.fillRect(25, HEIGHT - 350, 725, 200);
			pietruszkoBig.draw(620, 500);
			g.setColor(Color.white);
			drawWords(g, listOfSentences, 350);
			drawWords(g, listOfAnswers, 300);
			g.setColor(Color.white);
			g.drawString("'Spacebar' to end; 'w' to up; 's' to down; 'enter' to submit", 25, HEIGHT - fontHeight - 150);
			areActualAnswers = true;
		}
	}

	private void drawWords(Graphics g, ArrayList<String> list, int height) {
		int iteration = 0;
		for (String line : list) {
			if (line.contains(("(" + dialogIteration + ")"))) {
				if (listOfAnswers.equals(list)) {
					if (iteration == answerIteration)
						g.setColor(Color.yellow);
					else
						g.setColor(Color.white);
					if (!areActualAnswers) {
						actualAnswers.add(line);
						actualAnswersSize++;
					}
				}
				g.drawString(line.replaceAll("[0-9)(]", ""), 25, HEIGHT - height + fontHeight * iteration);
				iteration++;
			}
		}
	}

	public void movementLogic() {

		if (keyUp || keyDown || keyLeft || keyRight) {
			if (keyUp)
				velY = -1;
			else if (keyDown)
				velY = 1;
			else
				velY = 0;
			if (keyLeft)
				velX = -1;
			else if (keyRight)
				velX = 1;
			else
				velX = 0;
		} else {
			velX = 0;
			velY = 0;
		}
	}

	public void update(GameContainer gc, int i) throws SlickException {
		if (keyESC && !menuShown) {
			pause = true;
			menu.main = true;
		}
		menuLogic(gc);

		x += velX;
		y += velY;

	}

	public void walls(GameContainer gc) {
		if (x >= gc.getWidth() - 20)
			keyRight = false;
		if (x <= 8)
			keyLeft = false;
		if (y >= gc.getHeight() - 25)
			keyDown = false;
		if (y <= 8)
			keyUp = false;
	}

	public void render(GameContainer gc, Graphics g) throws SlickException {
		if (!menuShown && !pause) {
			if (fightableEntity) {
				fW.displayingWindow(g);
			} else {

				walls(gc);
				// tu rectangle wstawi�
				if ((x >= 410 && x <= 420) && (y >= 430 && y <= 440) && keyENTER) {
					level = 1;
					x = 284;
					y = 302;
					keyENTER = false;
				}
				character = new Rectangle(x, y, 16, 20);
				int arrLen = detection.RectArray.length;
				movementLogic();
				// level = 0 na dworze xd
				if (level == 0) {
					tlo.draw();

					// tutaj wroga wklei�
					for (Creature entry : enemiesLvl0.values()) {
						pietruszko.draw(entry.getWspX(), entry.getWspY());
					}

					for (int i = 0; i < arrLen; i++) {
						if (i < 11) {
							if (character.intersects(detection.RectArray[i])) {
								y = y + 1;
							}
						}
						if (i > 10 && i < 22) {
							if (character.intersects(detection.RectArray[i])) {
								x = x + 1;
							}
						}
						if (i > 21 && i < 32) {
							if (character.intersects(detection.RectArray[i])) {
								y = y - 1;
							}
						}
						if (i > 30 && i < 38) {
							if (character.intersects(detection.RectArray[i])) {
								x = x - 1;
							}
						}
					}
				}
				// dom npc
				else if (level == 1) {
					inn.draw(220, 200);
					pietruszko.draw(380, 220);
					if (dialogableEntity) {
						displayingDialogWindow(gc, g);
					} else if (keySPACE != false) {
						keySPACE = false;
						dialogIteration = 0;
						answerIteration = 0;
						actualAnswers = null;
					}
					if (keyENTER && y >= 293 && x >= 276 && x <= 293) {
						keyENTER = false;
						level = 0;
						x = 415;
						y = 435;
					}
				}
				if (fightableEntity == false) {
					if (velX > 0)
						heroWalksEast.draw(x, y);
					else if (velX < 0)
						heroWalksWest.draw(x, y);
					else if (velY > 0)
						heroWalksSouth.draw(x, y);
					else if (velY < 0)
						heroWalksNorth.draw(x, y);
					else
						heroWalksSouth.getImage(0).draw(x, y);
				}
				// Januszek doda�

			}
		} else {
			menuRender(gc, g);
		}
	}

	public void menuLogic(GameContainer gc) {
		if (menuShown) {
			if (keyUp)
				arrow--;
			if (keyDown)
				arrow++;
			if (keyENTER) {
				menu.enter = true;
				gc.sleep(100);
			}
			if (!keyENTER)
				menu.enter = false;
			if (menu.newGame) {
				menuShown = false;

			}
			gc.sleep(50);
		}
		if (pause) {
			if (keyUp)
				arrow--;
			if (keyDown)
				arrow++;
			if (keyENTER) {
				menu.enter = true;
				gc.sleep(100);
			}
			if (!keyENTER)
				menu.enter = false;
			gc.sleep(50);

		}
	}

	public void menuRender(GameContainer gc, Graphics g) {
		if (arrow > menu.menuItems)
			arrow--;
		if (arrow < 1)
			arrow++;
		if (menuShown) {
			menu.drawMenu(gc, g, (gc.getWidth() / 5), (gc.getHeight() / 5), arrow);
		}
		if (pause) {
			menu.drawPause(gc, g, (gc.getWidth() / 5), (gc.getHeight() / 5), arrow);
		}

	}

	public static void main(String[] args) {
		try {
			AppGameContainer appgc;
			appgc = new AppGameContainer(new JanuszekGame("Januszek"));
			appgc.setDisplayMode(HEIGHT, WIDTH, false);
			appgc.setVSync(true);
			appgc.setTargetFrameRate(60);
			appgc.start();
		} catch (SlickException ex) {
			Logger.getLogger(JanuszekGame.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}
