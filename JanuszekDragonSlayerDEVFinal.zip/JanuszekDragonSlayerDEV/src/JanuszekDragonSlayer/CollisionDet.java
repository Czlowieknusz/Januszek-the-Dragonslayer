package JanuszekDragonSlayer;

import org.newdawn.slick.geom.Rectangle;

public class CollisionDet {
	public Rectangle[] RectArray = new Rectangle[39];
	public Rectangle[] RectEnemies = new Rectangle[2];
	public Rectangle[] RectDialogable = new Rectangle[1];

	public CollisionDet() {
		// g�ra
		RectArray[0] = new Rectangle(0, 270, 300, 0);
		RectArray[1] = new Rectangle(390, 82, 58, 0);
		RectArray[2] = new Rectangle(448, 60, 225, 0);
		RectArray[3] = new Rectangle(366, 196, 65, 0);
		RectArray[4] = new Rectangle(364, 322, 99, 0);
		RectArray[5] = new Rectangle(465, 255, 70, 0);
		RectArray[6] = new Rectangle(540, 320, 75, 0);
		RectArray[7] = new Rectangle(620, 256, 50, 0);
		RectArray[8] = new Rectangle(370, 434, 100, 0);
		RectArray[9] = new Rectangle(300, 0, 90, 0);
		RectArray[10] = new Rectangle(537, 166, 74, 0);

		// lewo
		RectArray[11] = new Rectangle(305, 0, 0, 265);
		RectArray[12] = new Rectangle(448, 60, 0, 20);
		RectArray[13] = new Rectangle(109, 322, 0, 30);
		RectArray[14] = new Rectangle(239, 360, 0, 90);
		RectArray[15] = new Rectangle(276, 450, 0, 30);
		RectArray[16] = new Rectangle(468, 140, 0, 55);
		RectArray[17] = new Rectangle(465, 255, 0, 65);
		RectArray[18] = new Rectangle(620, 256, 0, 62);
		RectArray[19] = new Rectangle(480, 365, 0, 60);
		RectArray[20] = new Rectangle(0, 270, 0, 50);
		RectArray[21] = new Rectangle(625, 106, 0, 52);

		// d�l
		RectArray[22] = new Rectangle(0, 317, 105, 0);
		RectArray[23] = new Rectangle(115, 352, 115, 0);
		RectArray[24] = new Rectangle(242, 450, 30, 0);
		RectArray[25] = new Rectangle(285, 480, 380, 0);
		RectArray[26] = new Rectangle(468, 195, 200, 0);
		RectArray[27] = new Rectangle(366, 133, 100, 0);
		RectArray[28] = new Rectangle(364, 246, 60, 0);
		RectArray[29] = new Rectangle(370, 359, 100, 0);

		RectArray[30] = new Rectangle(535, 96, 80, 0);
		// prawo

		RectArray[31] = new Rectangle(385, 0, 0, 79);
		RectArray[32] = new Rectangle(672, 64, 0, 430);
		RectArray[33] = new Rectangle(366, 133, 0, 63);
		RectArray[34] = new Rectangle(431, 196, 0, 50);
		RectArray[35] = new Rectangle(364, 246, 0, 76);
		RectArray[36] = new Rectangle(535, 255, 0, 60);
		RectArray[37] = new Rectangle(367, 365, 0, 60);

		RectArray[38] = new Rectangle(526, 104, 0, 55);

		RectEnemies[0] = new Rectangle(300, 300, 32, 32);
		RectEnemies[1] = new Rectangle(400, 400, 32, 32);
		
		RectDialogable[0]=new Rectangle(380,220,10,10);
	}
}
