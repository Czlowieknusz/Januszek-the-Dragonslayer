package JanuszekDragonSlayer.Interactions;

import java.util.Map.Entry;

import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;

import JanuszekDragonSlayer.JanuszekGame;
import JanuszekDragonSlayer.Creatures.Creature;
import JanuszekDragonSlayer.Creatures.ID;

public class fightWindow {
	static Image fightBg;
	static Image enemyImg = null;
	static String[] firstOptions = { "1. Atak", "2. Obrona", "3. Potion (+5 hp)", "4. Ucieczka" };
	public static int chosenOption;
	public String enemyName;
	static boolean playersTurn;
	static int defending = 0;
	private static Creature enemy;
	private static Creature player;

	public fightWindow(Creature player, Creature enemy) {
		this.player = player;
		this.enemy = enemy;
		System.out.println(enemy.getHp());
		enemyName = enemy.getId().name();
		playersTurn = true;
		enemyImg = fightImages.enemyPicture(enemy.getId());
		fightBg = fightImages.fightBg;

	}

	public void displayingWindow(Graphics g) {
		fightBg.draw(0, 0);
		enemyImg.draw(450, 100);
		if (!playersTurn) {
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (defending > 0) {
				player.changeHp(2 - enemy.dealDamage());
				defending--;
			} else
				player.changeHp(-enemy.dealDamage());
			if (player.getHp() <= 0) {
				JanuszekGame.fightableEntity = false;
			}
			playersTurn = true;
		}
		g.setColor(Color.black);
		g.drawString(enemyName, 600, 320);
		g.drawString("HP " + enemy.getHp(), 600, 360);
		g.drawString("YOU", 20, 200);
		g.drawString("HP " + player.getHp(), 20, 240);
		g.drawString("Potions " + player.getNmbOfPots(), 20, 280);
		g.drawString("Defending turns " + defending, 20, 320);
		g.setColor(Color.white);
		for (int i = 0; i < 4; i++) {
			if (chosenOption == i)
				g.setColor(Color.yellow);
			g.drawString(firstOptions[i], 100, 480 + i * 30);
			g.setColor(Color.white);
		}
	}

	public static boolean choosingOption() {
		if (playersTurn) {
			if (chosenOption == 0) {

				enemy.changeHp(-player.dealDamage());

				if (enemy.getHp() <= 0) {
					for (Entry<Rectangle, Creature> entry : JanuszekGame.enemiesLvl0.entrySet()) {
						if (entry.getValue().getWspX() == enemy.getWspX()
								&& entry.getValue().getWspY() == enemy.getWspY()) {
							JanuszekGame.enemiesLvl0.remove(entry.getKey());
							return false;
						}
					}
					return true;
				}

			} else if (chosenOption == 1) {
				defending = 3;
			} else if (chosenOption == 2) {
				if (player.getNmbOfPots() > 0) {
					player.changeHp(5);
					player.changeNmbOfPots(-1);
				}
			} else if (chosenOption == 3) {
				if (enemy.getHp() <= 0) {
				} else if (defending > 0) {
					player.changeHp(2 - enemy.dealDamage());
					defending--;
				} else
					player.changeHp(-enemy.dealDamage());
				return false;
			}
			playersTurn = false;
		}
		return true;
	}
}
