package JanuszekDragonSlayer.Interactions;

import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

import JanuszekDragonSlayer.Creatures.ID;

public class fightImages {
	static Image fightBg;
	static Image ratata;
	public fightImages() {
		try {
			fightBg = new Image("walka.png");
			ratata = new Image("ratatafighta.png");
		} catch (SlickException e) {
			e.printStackTrace();
		}
	}

	public static Image enemyPicture(ID id) {
		if (id == ID.RATATA)
			return ratata;
		return null;
	}
}
