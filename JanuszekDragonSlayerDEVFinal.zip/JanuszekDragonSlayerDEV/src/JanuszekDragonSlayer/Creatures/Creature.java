package JanuszekDragonSlayer.Creatures;

import java.util.Random;

public class Creature {
	Random r = new Random();
	protected int hp;
	protected int maxDamage;
	protected int minDamage;
	protected int numberOfPotions;
	private int wspX;
	protected int wspY;
	private ID id;

	public Creature(int hp, int minDamage, int maxDamage, int numberOfPotions, ID id, int wspX, int wspY) {
		this.hp = hp;
		this.maxDamage = maxDamage;
		this.minDamage = minDamage;
		this.numberOfPotions = numberOfPotions;
		this.id=id;
		this.wspX=wspX;
		this.wspY = wspY;
	}

	public int dealDamage() {
		return r.nextInt(1 + maxDamage - minDamage) + minDamage;
	}

	public int getHp() {
		return hp;
	}

	public void changeHp(int hpChange) {
		this.hp += hpChange;
	}

	public int getNmbOfPots() {
		return numberOfPotions;
	}

	public void changeNmbOfPots(int nmbChange) {
		this.numberOfPotions += nmbChange;
	}

	public ID getId() {
		return id;
	}

	public void setId(ID id) {
		this.id = id;
	}

	public int getWspX() {
		return wspX;
	}

	public int getWspY() {
		return wspY;
	}
}
