package JanuszekDragonSlayer.Creatures;

public enum ID {
	RATATA("ratata"),
	PLAYER("player"),
	PIETRUSZKO("Pietruszko");
	
	final String name;
	private ID(String g){
		name=g;
	}
}
